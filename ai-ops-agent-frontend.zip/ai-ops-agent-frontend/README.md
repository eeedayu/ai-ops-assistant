# AI Ops Agent Frontend

React + Vite frontend for the AI Ops diagnosis Agent.

## Backend endpoints expected

- `POST /agent/run`
  - body: `{ "message": "...", "device_id": "device-003" }`
  - response status: `running | waiting_for_approval | completed | failed`
- `POST /agent/{run_id}/approve`
- `POST /agent/{run_id}/reject`
  - body: `{ "reason": "..." }`

## Start

```bash
npm install
cp .env.example .env
npm run dev
```

Default API base: `http://127.0.0.1:8000`.
